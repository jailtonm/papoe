import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PAPOE — O Brasil inteiro na mesma conexão",
  description: "Protótipo inicial da rede social brasileira PAPOE.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}
