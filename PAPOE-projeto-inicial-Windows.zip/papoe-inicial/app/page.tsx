"use client";

import { useMemo, useState } from "react";
import {
  Bell, Camera, Heart, Home, ImagePlus, MessageCircle, MessagesSquare,
  MoreHorizontal, Search, Send, Smile, Users, Video, Compass, UserRound,
  Plus, ThumbsUp, Menu, X, Paperclip, Play, LogIn
} from "lucide-react";

type Post = { id: number; name: string; initials: string; time: string; text: string; likes: number; liked: boolean; };

const starterPosts: Post[] = [
  { id: 1, name: "Ana Paula", initials: "AP", time: "há 12 min", text: "Bom dia, família PAPOE! 💚💛 Que hoje seja cheio de coisas boas para todos nós! 🇧🇷", likes: 12, liked: false },
  { id: 2, name: "Carlos Mendes", initials: "CM", time: "há 35 min", text: "Fim de tarde com os amigos e aquele pôr do sol incrível. ☀️", likes: 8, liked: false },
  { id: 3, name: "Juliana Costa", initials: "JC", time: "há 1 h", text: "Quem aí também ama descobrir lugares novos no Brasil? 🌴✈️", likes: 21, liked: false },
];

const initialMessages: Record<string, string[]> = {
  "Ana Paula": ["Oi! Bem-vindo ao PAPOE 😊", "Obrigado! Estou conhecendo a rede."],
  "Carlos Mendes": ["E aí, tudo certo? ⚽"],
  "Grupo da Família": ["Pessoal, tudo bem? 💚"],
};

export default function HomePage() {
  const [page, setPage] = useState("Início");
  const [posts, setPosts] = useState(starterPosts);
  const [postText, setPostText] = useState("");
  const [search, setSearch] = useState("");
  const [chat, setChat] = useState("Ana Paula");
  const [messages, setMessages] = useState(initialMessages);
  const [messageText, setMessageText] = useState("");
  const [groups, setGroups] = useState(["Amantes da música 🎵", "Comunidade de Louveira 📍", "Receitas do Brasil 🍲"]);
  const [groupName, setGroupName] = useState("");
  const [notice, setNotice] = useState("");
  const [profileName, setProfileName] = useState("Seu perfil");
  const [showMobileNav, setShowMobileNav] = useState(false);

  const navItems = [
    { label: "Início", icon: Home }, { label: "Amigos", icon: Users },
    { label: "Mensagens", icon: MessagesSquare }, { label: "Vídeos", icon: Video },
    { label: "Comunidades", icon: Compass }, { label: "Meu perfil", icon: UserRound },
  ];

  const filteredPosts = useMemo(
    () => posts.filter(p => `${p.name} ${p.text}`.toLowerCase().includes(search.toLowerCase())),
    [posts, search]
  );

  function notify(text: string) {
    setNotice(text);
    window.setTimeout(() => setNotice(""), 2600);
  }

  function publish() {
    if (!postText.trim()) return notify("Escreva algo antes de publicar.");
    setPosts([{ id: Date.now(), name: profileName === "Seu perfil" ? "Você" : profileName, initials: "EU", time: "agora", text: postText.trim(), likes: 0, liked: false }, ...posts]);
    setPostText("");
    notify("Publicação adicionada nesta demonstração.");
  }

  function sendMessage() {
    if (!messageText.trim()) return;
    setMessages({ ...messages, [chat]: [...(messages[chat] || []), messageText.trim()] });
    setMessageText("");
  }

  function createGroup() {
    if (!groupName.trim()) return;
    setGroups([...groups, groupName.trim()]);
    setGroupName("");
    notify("Grupo criado nesta demonstração.");
  }

  return (
    <main className="app-shell">
      <header className="topbar">
        <button className="brand" onClick={() => setPage("Início")} aria-label="Ir para o início">
          <span className="brand-mark"><MessageCircle size={23} fill="currentColor" /></span>
          <span>PAPOE<span className="brand-dot">.</span><small>O Brasil inteiro na mesma conexão!</small></span>
        </button>
        <label className="searchbox"><Search size={18}/><input value={search} onChange={e => {setSearch(e.target.value); setPage("Início");}} placeholder="Buscar no PAPOE..." /></label>
        <div className="top-actions"><button className="icon-button" onClick={() => notify("Você está em dia com as notificações.")} aria-label="Notificações"><Bell size={20}/></button><button className="profile-chip" onClick={() => setPage("Meu perfil")}><span className="avatar">😎</span><b>Você</b></button></div>
        <button className="icon-button mobile-menu" onClick={() => setShowMobileNav(!showMobileNav)} aria-label="Menu">{showMobileNav ? <X/> : <Menu/>}</button>
      </header>

      <div className="layout">
        <aside className={`sidebar ${showMobileNav ? "sidebar-open" : ""}`}>
          <div className="mini-profile"><span className="avatar">😎</span><div><b>{profileName}</b><small>Bem-vindo ao PAPOE</small></div></div>
          <nav className="nav-list">
            {navItems.map(item => { const Icon = item.icon; return <button key={item.label} className={`nav-item ${page === item.label ? "selected" : ""}`} onClick={() => {setPage(item.label); setShowMobileNav(false);}}><Icon size={19}/>{item.label}</button>; })}
          </nav>
          <div className="brazil-card"><span>🇧🇷</span><b>Feito para conectar</b><p>Sua comunidade, suas conversas, seu Brasil.</p></div>
          <p className="sidebar-foot">PAPOE © 2026 · Protótipo inicial</p>
        </aside>

        <section className="content">
          {page === "Início" && <>
            <div className="welcome-banner"><div className="banner-kicker">SUA REDE. SUA CONEXÃO.</div><h1>O Brasil inteiro<br/>no PAPOE! <span>🇧🇷</span></h1><p>Compartilhe momentos e fique perto de quem importa.</p><div className="banner-shapes"><span>💚</span><span>💛</span><span>💬</span></div></div>
            <div className="stories card"><button className="story" onClick={() => notify("A publicação de status será conectada ao envio de mídia.")}><span className="story-ring add-story"><Plus/></span><small>Seu status</small></button>{[["👩🏻","Ana"],["🧑🏽","Carlos"],["👩🏾","Juliana"],["🧔🏻","Rafael"]].map(([emoji,name])=><button className="story" key={name} onClick={() => notify(`Status de ${name}: demonstração.`)}><span className="story-ring"><span className="story-emoji">{emoji}</span></span><small>{name}</small></button>)}</div>
            <div className="composer card"><div className="composer-top"><span className="avatar">😎</span><textarea value={postText} onChange={e => setPostText(e.target.value)} placeholder="O que você quer compartilhar?" rows={2}/></div><div className="composer-bottom"><div className="composer-tools"><button onClick={() => notify("Upload de fotos será habilitado ao integrar o armazenamento.")}><ImagePlus size={17}/> Foto</button><button onClick={() => notify("Upload de vídeos será habilitado ao integrar o armazenamento.")}><Video size={17}/> Vídeo</button><button onClick={() => setPostText(postText + (postText ? " " : "") + "😊 Sentindo-se bem")}><Smile size={17}/> Sentimento</button></div><button className="primary-button" onClick={publish}>Publicar <Send size={15}/></button></div></div>
            <div className="section-heading"><h2>Feed de publicações</h2><span>Mais recentes</span></div>
            <div className="post-list">{filteredPosts.map(post => <article className="card post" key={post.id}><div className="post-head"><span className="avatar avatar-color">{post.initials}</span><div className="post-author"><b>{post.name}</b><small>{post.time} · 🌎</small></div><button className="icon-button" aria-label="Mais opções" onClick={() => notify("Opções da publicação em desenvolvimento.")}><MoreHorizontal/></button></div><p className="post-text">{post.text}</p><div className="post-stats"><span>💚 {post.likes} curtidas</span><span>💬 Comentários em breve</span></div><div className="post-actions"><button className={post.liked ? "liked" : ""} onClick={() => setPosts(posts.map(p => p.id === post.id ? {...p, liked: !p.liked, likes: p.likes + (p.liked ? -1 : 1)} : p))}><Heart size={18} fill={post.liked ? "currentColor" : "none"}/> Curtir</button><button onClick={() => notify("Comentários serão conectados ao banco de dados.")}><MessageCircle size={18}/> Comentar</button><button onClick={() => {navigator.clipboard?.writeText(post.text); notify("Texto copiado para compartilhar.");}}><Send size={17}/> Compartilhar</button></div></article>)}</div>
          </>}

          {page === "Mensagens" && <div className="card chat-card"><div className="section-heading"><div><h2>Mensagens</h2><p>Conversas de demonstração</p></div><MessagesSquare color="#07883e"/></div><div className="chat-layout"><div className="chat-list">{Object.keys(messages).map(name => <button key={name} className={`chat-contact ${chat === name ? "chat-selected" : ""}`} onClick={() => setChat(name)}><span className="avatar">{name === "Ana Paula" ? "👩🏻" : name === "Carlos Mendes" ? "🧑🏽" : "👨‍👩‍👧"}</span><span><b>{name}</b><small>{messages[name].at(-1) || "Comece uma conversa"}</small></span></button>)}</div><div className="chat-window"><div className="chat-header"><span className="avatar">💬</span><div><b>{chat}</b><small>Conversa local de teste</small></div></div><div className="chat-messages">{(messages[chat] || []).map((msg, i) => <div className={`bubble ${i % 2 ? "bubble-mine" : ""}`} key={`${i}-${msg}`}>{msg}<small>{i % 2 ? "Você · " : ""}agora</small></div>)}</div><form className="message-form" onSubmit={e => {e.preventDefault(); sendMessage();}}><button type="button" className="icon-button" onClick={() => notify("Anexos de mídia precisam de armazenamento configurado.")} aria-label="Anexar arquivo"><Paperclip/></button><input value={messageText} onChange={e => setMessageText(e.target.value)} placeholder="Digite uma mensagem..." /><button className="send-button" type="submit" aria-label="Enviar"><Send size={18}/></button></form><p className="demo-note">As mensagens ficam apenas nesta sessão do navegador.</p></div></div></div>}

          {page === "Amigos" && <div className="card simple-page"><h1>👥 Amigos</h1><p>Conheça pessoas e amplie sua rede.</p><div className="people-grid">{[["👩🏻","Ana Paula","São Paulo"],["🧑🏽","Carlos Mendes","Campinas"],["👩🏾","Juliana Costa","Belo Horizonte"],["🧔🏻","Rafael Lima","Curitiba"]].map(([emoji,name,city])=><div className="person-card" key={name}><span className="avatar big-avatar">{emoji}</span><b>{name}</b><small>{city}</small><button className="primary-button" onClick={() => notify(`Convite de amizade demonstrativo para ${name}.`)}>Adicionar amigo</button></div>)}</div></div>}

          {page === "Vídeos" && <div className="card simple-page"><h1>▶ Vídeos PAPOE</h1><p>Um espaço para criadores e conteúdos brasileiros.</p><div className="video-grid"><button onClick={() => notify("O envio e a reprodução de vídeos serão conectados ao armazenamento.")} className="video-tile video-purple"><Play size={36}/><b>Música e diversão</b><small>Compartilhe seus sons favoritos</small></button><button onClick={() => notify("O envio e a reprodução de vídeos serão conectados ao armazenamento.")} className="video-tile video-green"><Camera size={36}/><b>Vida no Brasil</b><small>Momentos, lugares e histórias</small></button></div><div className="notice-box">O upload e a reprodução de vídeos reais serão adicionados na próxima etapa.</div></div>}

          {page === "Comunidades" && <div className="card simple-page"><h1>🌎 Comunidades</h1><p>Crie grupos e reúna pessoas com interesses em comum.</p><form className="create-group" onSubmit={e => {e.preventDefault(); createGroup();}}><input value={groupName} onChange={e => setGroupName(e.target.value)} placeholder="Nome da nova comunidade"/><button className="primary-button" type="submit"><Plus size={17}/> Criar grupo</button></form><div className="group-list">{groups.map((g,i)=><div className="group-row" key={`${g}-${i}`}><span className="group-icon">👥</span><div><b>{g}</b><small>Comunidade PAPOE · grupo de demonstração</small></div><button className="secondary-button" onClick={() => {setChat(g);if(!messages[g])setMessages({...messages,[g]:[]});setPage("Mensagens");}}>Abrir chat</button></div>)}</div></div>}

          {page === "Meu perfil" && <div className="card simple-page"><div className="profile-cover"><span className="avatar profile-avatar">😎</span><h1>{profileName}</h1><p>Membro da comunidade PAPOE 🇧🇷</p></div><div className="profile-edit"><label htmlFor="profileName">Nome do perfil</label><input id="profileName" value={profileName} onChange={e => setProfileName(e.target.value)} /><p>Alterações são mantidas nesta sessão de demonstração.</p><div className="profile-stats"><div><b>{posts.filter(p => p.name === "Você" || p.name === profileName).length}</b><small>Publicações</small></div><div><b>{Object.keys(messages).length}</b><small>Conversas</small></div><div><b>{groups.length}</b><small>Grupos</small></div></div></div></div>}
        </section>

        <aside className="rightbar"><div className="card right-card"><h3>🇧🇷 Em destaque</h3><p>O que está acontecendo na nossa comunidade.</p><div className="trend"><span>🎶</span><div><b>Música brasileira</b><small>Compartilhe seus sons favoritos</small></div></div><div className="trend"><span>⚽</span><div><b>Paixão pelo futebol</b><small>Converse sobre seu time</small></div></div><div className="trend"><span>🍲</span><div><b>Culinária do Brasil</b><small>Receitas de todo o país</small></div></div></div><div className="card right-card"><h3>✨ Sobre o PAPOE</h3><p>Uma ideia brasileira para aproximar pessoas, comunidades e negócios.</p><div className="notice-box">Este projeto ainda está em desenvolvimento. Não use dados pessoais reais nesta demonstração.</div></div></aside>
      </div>
      {notice && <div className="toast">{notice}</div>}
      <footer className="footer"><span>🇧🇷 PAPOE</span><span>O Brasil inteiro na mesma conexão.</span><span>Protótipo inicial · 2026</span></footer>
    </main>
  );
}
